package hu.ppke.itk.plang.gui;

import java.awt.Component;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class PrefDialog extends JDialog {
   private JComboBox fontCombo;
   private JSpinner fontSize;
   private JSpinner stepNum;
   private boolean result;
   private int font;
   private int size;
   private int step;

   PrefDialog(JFrame owner) {
      super(owner, "Beállítások", true);
      JPanel panel = new JPanel();
      panel.setLayout(new BoxLayout(panel, 1));
      JPanel fontPanel = new JPanel();
      fontPanel.add(new JLabel("Betűtípus:"));
      this.fontCombo = new JComboBox(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
      this.fontCombo.setSelectedItem("Monospaced");
      this.fontCombo.setRenderer(new DefaultListCellRenderer() {
         public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            Component c = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            c.setFont(new Font((String)value, 0, 14));
            return c;
         }
      });
      fontPanel.add(this.fontCombo);
      this.fontSize = new JSpinner(new SpinnerNumberModel(12, 6, 48, 2));
      fontPanel.add(this.fontSize);
      panel.add(fontPanel);
      JPanel stepPanel = new JPanel();
      stepPanel.add(new JLabel("Lépésszám:"));
      this.stepNum = new JSpinner(new SpinnerNumberModel(10000, 10, 100000, 1000));
      stepPanel.add(this.stepNum);
      panel.add(stepPanel);
      this.getContentPane().add(panel);
      JPanel btnPanel = new JPanel();
      btnPanel.add(new JButton(new AbstractAction("OK") {
         public void actionPerformed(ActionEvent e) {
            synchronized(PrefDialog.this) {
               PrefDialog.this.setVisible(false);
               PrefDialog.this.result = true;
               PrefDialog.this.notifyAll();
            }
         }
      }));
      btnPanel.add(new JButton(new AbstractAction("Mégsem") {
         public void actionPerformed(ActionEvent e) {
            synchronized(PrefDialog.this) {
               PrefDialog.this.setVisible(false);
               PrefDialog.this.notifyAll();
            }
         }
      }));
      this.getContentPane().add(btnPanel, "South");
      this.pack();
   }

   Font getTextFont() {
      return new Font((String)this.fontCombo.getSelectedItem(), 0, (Integer)this.fontSize.getValue());
   }

   int getStepNum() {
      return (Integer)this.stepNum.getValue();
   }

   private void save() {
      this.font = this.fontCombo.getSelectedIndex();
      this.size = (Integer)this.fontSize.getValue();
      this.step = (Integer)this.stepNum.getValue();
   }

   private void restore() {
      this.fontCombo.setSelectedIndex(this.font);
      this.fontSize.setValue(this.size);
      this.stepNum.setValue(this.step);
   }

   synchronized boolean showDlg() {
      this.result = false;
      this.save();
      this.setVisible(true);

      while(this.isVisible()) {
         try {
            this.wait();
         } catch (InterruptedException var2) {
         }
      }

      if (!this.result) {
         this.restore();
      }

      return this.result;
   }
}
