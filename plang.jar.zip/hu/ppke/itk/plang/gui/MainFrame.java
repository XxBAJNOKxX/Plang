package hu.ppke.itk.plang.gui;

import hu.ppke.itk.plang.prog.Lexer;
import hu.ppke.itk.plang.prog.MainProgram;
import hu.ppke.itk.plang.prog.State;
import hu.ppke.itk.plang.prog.StreamData;
import hu.ppke.itk.plang.prog.StreamKind;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.TreePath;

public class MainFrame extends JFrame {
   private Icon loadIcon;
   private Icon runIcon;
   private Icon stopIcon;
   private Icon parseIcon;
   private Icon copyIcon;
   private Icon editIcon;
   private Icon saveIcon;
   private Icon prefIcon;
   private JFileChooser fileChooser;
   private Action loadAction;
   private Action saveAction;
   private Action parseAction;
   private Action editAction;
   private Action copyAction;
   private Action runAction;
   private Action stopAction;
   private Action enterAction;
   private Action leaveAction;
   private PrefDialog prefDialog;
   private Action showPreferences;
   private ListSelectionListener selProgLine;
   private ListSelectionListener selProgState;
   private TreeSelectionListener selExprNode;
   private JList progList;
   private JTextArea progText;
   private boolean progTextChanged;
   private static final String PROGLIST = "ProgList";
   private static final String PROGTEXT = "ProgText";
   private JPanel progPanel;
   private JList callStack;
   private JTable stateTable;
   private JTree exprTree;
   private JTabbedPane inpPanes;
   private JTabbedPane outPanes;
   private Font textFont;

   private void editState() {
      this.loadAction.setEnabled(true);
      this.saveAction.setEnabled(true);
      this.parseAction.setEnabled(true);
      this.editAction.setEnabled(false);
      this.copyAction.setEnabled(false);
      this.runAction.setEnabled(false);
      ((CardLayout)this.progPanel.getLayout()).show(this.progPanel, "ProgText");
   }

   private void listState() {
      this.loadAction.setEnabled(false);
      this.saveAction.setEnabled(false);
      this.parseAction.setEnabled(false);
      this.editAction.setEnabled(true);
      ((CardLayout)this.progPanel.getLayout()).show(this.progPanel, "ProgList");
   }

   private void runState() {
      this.editAction.setEnabled(false);
      this.copyAction.setEnabled(false);
      this.runAction.setEnabled(false);
      this.stopAction.setEnabled(true);

      for(int i = 0; i < this.inpPanes.getComponentCount(); ++i) {
         ((JTextPane)((JScrollPane)this.inpPanes.getComponentAt(i)).getViewport().getView()).setEditable(false);
      }

   }

   private void stopState() {
      this.editAction.setEnabled(true);
      this.copyAction.setEnabled(true);
      this.runAction.setEnabled(true);
      this.stopAction.setEnabled(false);
      this.enterAction.setEnabled(false);
      this.leaveAction.setEnabled(false);

      for(int i = 0; i < this.inpPanes.getComponentCount(); ++i) {
         JTextPane p = (JTextPane)((JScrollPane)this.inpPanes.getComponentAt(i)).getViewport().getView();
         p.setEditable(true);
         p.setCharacterAttributes(StreamDocument.getNormalAttr(), true);
      }

   }

   private static StreamDocument getDocument(JTabbedPane panes, int ind) {
      return (StreamDocument)((JTextPane)((JScrollPane)panes.getComponentAt(ind)).getViewport().getView()).getDocument();
   }

   private void updatePanes(JTabbedPane panes, Set<String> streams, boolean edit) {
      int ind = 0;
      Iterator<String> files = streams.iterator();
      String f = files.hasNext() ? (String)files.next() : null;
      String t = ind < panes.getComponentCount() ? panes.getTitleAt(ind) : null;

      while(f != null || t != null) {
         if (f != null && (t == null || t.compareTo(f) >= 0)) {
            if (t == null || f != null && f.compareTo(t) < 0) {
               JTextPane text = new JTextPane(new StreamDocument());
               text.setFont(this.textFont);
               text.setCharacterAttributes(StreamDocument.getNormalAttr(), true);
               text.setEditable(edit);
               panes.insertTab(f, (Icon)null, new JScrollPane(text), (String)null, ind);
               ++ind;
               f = files.hasNext() ? (String)files.next() : null;
            } else {
               ++ind;
               t = ind < panes.getComponentCount() ? panes.getTitleAt(ind) : null;
               f = files.hasNext() ? (String)files.next() : null;
            }
         } else {
            panes.remove(ind);
            t = ind < panes.getComponentCount() ? panes.getTitleAt(ind) : null;
         }
      }

   }

   private static void setStreamStates(JTabbedPane panes, State state) {
      for(int i = 0; i < panes.getComponentCount(); ++i) {
         getDocument(panes, i).setState(state == null ? null : state.getStreamState(panes.getTitleAt(i)));
      }

   }

   private void updateFont() {
      this.progList.setCellRenderer(new ProgLineRenderer(this.textFont));
      this.stateTable.setFont(this.textFont);
      this.stateTable.setRowHeight(this.stateTable.getGraphics().getFontMetrics(this.textFont).getHeight());
      this.stateTable.getTableHeader().setFont(this.textFont);
      this.stateTable.getParent().setFont(this.textFont);
      this.progText.setFont(this.textFont);
      this.exprTree.setCellRenderer(new ExprRenderer(this.textFont));

      for(int i = 0; i < this.inpPanes.getComponentCount(); ++i) {
         ((JScrollPane)this.inpPanes.getComponentAt(i)).getViewport().getView().setFont(this.textFont);
      }

      for(int i = 0; i < this.outPanes.getComponentCount(); ++i) {
         ((JScrollPane)this.outPanes.getComponentAt(i)).getViewport().getView().setFont(this.textFont);
      }

   }

   public MainFrame() {
      super("PLanG");
      ClassLoader cl = this.getClass().getClassLoader();
      this.loadIcon = new ImageIcon(cl.getResource("images/load.png"));
      this.runIcon = new ImageIcon(cl.getResource("images/run.png"));
      this.stopIcon = new ImageIcon(cl.getResource("images/stop.png"));
      this.parseIcon = new ImageIcon(cl.getResource("images/parse.png"));
      this.copyIcon = new ImageIcon(cl.getResource("images/copy.png"));
      this.editIcon = new ImageIcon(cl.getResource("images/edit.png"));
      this.saveIcon = new ImageIcon(cl.getResource("images/save.png"));
      this.prefIcon = new ImageIcon(cl.getResource("images/pref.png"));
      this.fileChooser = new JFileChooser();
      this.fileChooser.addChoosableFileFilter(new PlangFilter((PlangFilter)null));
      this.loadAction = new AbstractAction("Betölt", this.loadIcon) {
         public void actionPerformed(ActionEvent ev) {
            if (!MainFrame.this.progTextChanged || JOptionPane.showConfirmDialog(MainFrame.this, "A programszöveg változásai nincsenek elmentve. Biztosan be akarsz tölteni egy új fájlt?", "Betöltés", 0, 2) == 0) {
               try {
                  if (MainFrame.this.fileChooser.showOpenDialog(MainFrame.this) == 0) {
                     BufferedReader rd = new BufferedReader(new InputStreamReader(new FileInputStream(MainFrame.this.fileChooser.getSelectedFile()), "ISO-8859-2"));
                     MainFrame.this.progText.setText("");

                     for(String line = rd.readLine(); line != null; line = rd.readLine()) {
                        MainFrame.this.progText.append(line + "\n");
                     }

                     rd.close();
                     MainFrame.this.progTextChanged = false;
                  }
               } catch (FileNotFoundException e) {
                  JOptionPane.showMessageDialog(MainFrame.this, "Nem sikerült az olvasás a következö fájlból: " + e.getMessage(), "Hiba a megnyitás során", 0);
                  System.err.println(e.getMessage());
               } catch (IOException e) {
                  JOptionPane.showMessageDialog(MainFrame.this, "Nem sikerült az olvasás a következő fájlból: " + e.getMessage(), "Hiba az olvasás során", 0);
                  System.err.println(e.getMessage());
               }

            }
         }
      };
      this.saveAction = new AbstractAction("Ment", this.saveIcon) {
         public void actionPerformed(ActionEvent ev) {
            try {
               if (MainFrame.this.fileChooser.showSaveDialog(MainFrame.this) == 0 && (!MainFrame.this.fileChooser.getSelectedFile().exists() || JOptionPane.showConfirmDialog(MainFrame.this, "A fájl létezik, felülírjam?", "Létező fájl", 0, 3) == 0)) {
                  PrintWriter wr = new PrintWriter(new OutputStreamWriter(new FileOutputStream(MainFrame.this.fileChooser.getSelectedFile()), "ISO-8859-2"));
                  wr.print(MainFrame.this.progText.getText());
                  wr.close();
                  MainFrame.this.progTextChanged = false;
               }
            } catch (IOException e) {
               JOptionPane.showMessageDialog(MainFrame.this, "Nem sikerült a mentés a következő fájlba: " + e.getMessage(), "Hiba a mentés során", 0);
               System.err.println(e.getMessage());
            }

         }
      };
      this.parseAction = new AbstractAction("Értelmez", this.parseIcon) {
         public void actionPerformed(ActionEvent ev) {
            try {
               MainProgram prog = MainProgram.parseMainProgram(new Lexer(new StringReader(MainFrame.this.progText.getText())));
               ((ProgramList)MainFrame.this.progList.getModel()).setProgram(prog);
               MainFrame.this.listState();
               boolean ok = !prog.hasError();
               MainFrame.this.runAction.setEnabled(ok);
               MainFrame.this.copyAction.setEnabled(ok);
               if (ok) {
                  MainFrame.this.updatePanes(MainFrame.this.inpPanes, prog.getStreams(StreamKind.INPUT), true);
                  MainFrame.this.updatePanes(MainFrame.this.outPanes, prog.getStreams(StreamKind.OUTPUT), false);
               }
            } catch (Throwable t) {
               if ("off".equals(System.getProperty("hu.ppke.itk.plang.errorDlg"))) {
                  throw new RuntimeException(t);
               }

               JOptionPane.showMessageDialog(MainFrame.this, "Belső hiba történt a szöveg értelmezése közben.", "HIBA", 0);
            }

         }
      };
      this.editAction = new AbstractAction("Szerkeszt", this.editIcon) {
         public void actionPerformed(ActionEvent ev) {
            MainFrame.this.editState();
         }
      };
      this.copyAction = new AbstractAction("Másol", this.copyIcon) {
         private String unHtml(String h) {
            StringBuffer s = new StringBuffer();

            for(int i = 0; i < h.length(); ++i) {
               if (h.charAt(i) == '&') {
                  String ent = h.substring(i + 1, h.indexOf(59, i + 1));
                  if (ent.equals("lt")) {
                     s.append('<');
                  } else if (ent.equals("gt")) {
                     s.append('>');
                  } else if (ent.equals("nbsp")) {
                     s.append(' ');
                  } else if (ent.equals("amp")) {
                     s.append('&');
                  } else {
                     s.append('?');
                  }

                  i += ent.length() + 1;
               } else {
                  s.append(h.charAt(i));
               }
            }

            return s.toString();
         }

         public void actionPerformed(ActionEvent ev) {
            MainFrame.this.progText.setText("");
            ProgramList lst = (ProgramList)MainFrame.this.progList.getModel();

            for(int i = 0; i < lst.getSize(); ++i) {
               MainFrame.this.progText.append(this.unHtml(lst.getElementAt(i).toString()) + "\n");
            }

            MainFrame.this.editState();
         }
      };
      this.runAction = new AbstractAction("Start", this.runIcon) {
         public void actionPerformed(ActionEvent ev) {
            MainProgram prog = ((ProgramList)MainFrame.this.progList.getModel()).getProgram();
            if (prog != null && !prog.hasError()) {
               Map<String, String> input = new HashMap();

               for(int i = 0; i < MainFrame.this.inpPanes.getComponentCount(); ++i) {
                  input.put(MainFrame.this.inpPanes.getTitleAt(i), MainFrame.getDocument(MainFrame.this.inpPanes, i).getText());
               }

               CallStack cs = (CallStack)MainFrame.this.callStack.getModel();

               try {
                  Map<String, StreamData> output = new TreeMap();
                  State last = cs.runProgram(prog, input, output);

                  for(int i = 0; i < MainFrame.this.outPanes.getComponentCount(); ++i) {
                     MainFrame.getDocument(MainFrame.this.outPanes, i).setStream((StreamData)output.get(MainFrame.this.outPanes.getTitleAt(i)));
                  }

                  MainFrame.this.runState();
                  MainFrame.this.stateTable.setRowSelectionInterval(MainFrame.this.stateTable.getRowCount() - 1, MainFrame.this.stateTable.getRowCount() - 1);
                  MainFrame.this.stateTable.scrollRectToVisible(MainFrame.this.stateTable.getCellRect(MainFrame.this.stateTable.getSelectedRow(), MainFrame.this.stateTable.getSelectedColumn(), true));
                  if (last.getError() != null) {
                     JOptionPane.showMessageDialog(MainFrame.this, "A program futása a következő hiba miatt megszakadt:\n" + last.getError(), "Futási hiba", 2);
                  }
               } catch (OutOfMemoryError var8) {
                  JOptionPane.showMessageDialog(MainFrame.this, "Elfogyott a memória a program futásának szimulációja során.\nPróbálkozz kevesebb lépést végrehajtani, vagy kisebb tömböket használni.", "Hiba", 0);
               } catch (Throwable t) {
                  if ("off".equals(System.getProperty("hu.ppke.itk.plang.errorDlg"))) {
                     throw new RuntimeException(t);
                  }

                  JOptionPane.showMessageDialog(MainFrame.this, "Belső hiba történt a program futásának szimulációja közben.", "HIBA", 0);
               }
            }

         }
      };
      this.stopAction = new AbstractAction("Stop", this.stopIcon) {
         public void actionPerformed(ActionEvent e) {
            CallStack cs = (CallStack)MainFrame.this.callStack.getModel();
            cs.runProgram((MainProgram)null, (Map)null, (Map)null);
            MainFrame.setStreamStates(MainFrame.this.inpPanes, (State)null);

            for(int i = 0; i < MainFrame.this.outPanes.getComponentCount(); ++i) {
               MainFrame.getDocument(MainFrame.this.outPanes, i).setStream((StreamData)null);
            }

            MainFrame.this.stopState();
         }
      };
      this.enterAction = new AbstractAction("Enter") {
         public void actionPerformed(ActionEvent e) {
            ExprNode n = (ExprNode)MainFrame.this.exprTree.getSelectionPath().getLastPathComponent();
            List<State> sp = n.getSubStates();
            if (sp != null) {
               ((CallStack)MainFrame.this.callStack.getModel()).enter(n.toString(), sp);
            }

            MainFrame.this.leaveAction.setEnabled(true);
         }
      };
      this.leaveAction = new AbstractAction("Leave") {
         public void actionPerformed(ActionEvent e) {
            ((CallStack)MainFrame.this.callStack.getModel()).leave();
            if (MainFrame.this.callStack.getModel().getSize() <= 1) {
               MainFrame.this.leaveAction.setEnabled(false);
            }

         }
      };
      this.showPreferences = new AbstractAction("Beállítások", this.prefIcon) {
         public void actionPerformed(ActionEvent e) {
            if (MainFrame.this.prefDialog.showDlg()) {
               MainFrame.this.textFont = MainFrame.this.prefDialog.getTextFont();
               MainFrame.this.updateFont();
               ((CallStack)MainFrame.this.callStack.getModel()).setMaxSteps(MainFrame.this.prefDialog.getStepNum());
            }

         }
      };
      this.loadAction.putValue("ShortDescription", "Betöltés");
      this.saveAction.putValue("ShortDescription", "Kimentés");
      this.parseAction.putValue("ShortDescription", "Programszöveg értelmezése");
      this.editAction.putValue("ShortDescription", "Szerkesztés");
      this.copyAction.putValue("ShortDescription", "Értelmezett program szerkesztése");
      this.runAction.putValue("ShortDescription", "Futtatás");
      this.stopAction.putValue("ShortDescription", "Futtatás vége");
      this.stopAction.setEnabled(false);
      this.enterAction.putValue("ShortDescription", "Belépés alprogramba");
      this.enterAction.setEnabled(false);
      this.leaveAction.putValue("ShortDescription", "Alprogram elhagyása");
      this.leaveAction.setEnabled(false);
      this.showPreferences.putValue("ShortDescription", "Beállítások");
      this.selProgLine = new ListSelectionListener() {
         public void valueChanged(ListSelectionEvent ev) {
            if (!ev.getValueIsAdjusting()) {
               ProgramLine line = (ProgramLine)MainFrame.this.progList.getSelectedValue();
               if (line != null) {
                  ((ExprTree)MainFrame.this.exprTree.getModel()).setRoot(line.getExpr((State)null));
               } else {
                  ((ExprTree)MainFrame.this.exprTree.getModel()).setRoot((ExprNode)null);
               }
            }

         }
      };
      this.selProgState = new ListSelectionListener() {
         public void valueChanged(ListSelectionEvent ev) {
            if (!ev.getValueIsAdjusting()) {
               State state = ((StateList)MainFrame.this.stateTable.getModel()).getState(MainFrame.this.stateTable.getSelectedRow());
               if (state == null) {
                  MainFrame.this.progList.setSelectedIndex(-1);
                  ((ExprTree)MainFrame.this.exprTree.getModel()).setRoot(ExprNode.EMPTY);
               } else {
                  ProgramLine line = (ProgramLine)MainFrame.this.progList.getModel().getElementAt(state.getLine());
                  if (state.getError() == null) {
                     MainFrame.this.progList.setSelectedIndex(state.getLine());
                     MainFrame.this.progList.ensureIndexIsVisible(MainFrame.this.progList.getSelectedIndex());
                     ((ExprTree)MainFrame.this.exprTree.getModel()).setRoot(line.getExpr(state));
                  } else {
                     MainFrame.this.progList.setSelectedIndex(state.getLine());
                     ((ExprTree)MainFrame.this.exprTree.getModel()).setRoot(new ExprNode("<font color=\"red\">" + state.getError() + "</font>", new ExprNode[0], (String)null));
                  }

                  MainFrame.setStreamStates(MainFrame.this.inpPanes, state);
                  MainFrame.setStreamStates(MainFrame.this.outPanes, state);
               }
            }

         }
      };
      this.selExprNode = new TreeSelectionListener() {
         public void valueChanged(TreeSelectionEvent e) {
            TreePath p = MainFrame.this.exprTree.getSelectionPath();
            if (p != null) {
               ExprNode node = (ExprNode)p.getLastPathComponent();
               MainFrame.this.enterAction.setEnabled(node.getSubStates() != null);
            } else {
               MainFrame.this.enterAction.setEnabled(false);
            }

         }
      };
      this.progTextChanged = false;
      this.setDefaultCloseOperation(0);
      this.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            if (!MainFrame.this.progTextChanged || JOptionPane.showConfirmDialog(MainFrame.this, "A programszöveg változásai nincsenek elmentve. Biztosan ki akarsz lépni?", "Kilépés", 0, 2) == 0) {
               MainFrame.this.dispose();
            }

         }
      });
      this.prefDialog = new PrefDialog(this);
      JToolBar toolbar = new JToolBar();
      toolbar.add(this.loadAction);
      toolbar.add(this.saveAction);
      toolbar.addSeparator();
      toolbar.add(this.parseAction);
      toolbar.add(this.editAction);
      toolbar.add(this.copyAction);
      toolbar.addSeparator();
      toolbar.add(this.runAction);
      toolbar.add(this.stopAction);
      if ("on".equals(System.getProperty("hu.ppke.itk.plang.subprograms"))) {
         toolbar.addSeparator();
         toolbar.add(this.enterAction);
         toolbar.add(this.leaveAction);
      }

      toolbar.addSeparator();
      toolbar.add(this.showPreferences);
      toolbar.setFloatable(false);
      this.getContentPane().add(toolbar, "First");
      this.textFont = new Font("Monospaced", 0, 12);
      this.progList = new JList(new ProgramList());
      this.progList.setCellRenderer(new ProgLineRenderer(this.textFont));
      this.progList.setSelectionMode(0);
      this.progList.addListSelectionListener(this.selProgLine);
      JScrollPane progScrl = new JScrollPane(this.progList);
      this.progText = new JTextArea();
      this.progText.setFont(this.textFont);
      this.progText.getDocument().addDocumentListener(new DocumentListener() {
         public void changedUpdate(DocumentEvent e) {
            MainFrame.this.progTextChanged = true;
         }

         public void insertUpdate(DocumentEvent e) {
            MainFrame.this.progTextChanged = true;
         }

         public void removeUpdate(DocumentEvent e) {
            MainFrame.this.progTextChanged = true;
         }
      });
      JScrollPane textScrl = new JScrollPane(this.progText);
      this.progPanel = new JPanel(new CardLayout());
      this.progPanel.add(progScrl, "ProgList");
      this.progPanel.add(textScrl, "ProgText");
      this.exprTree = new JTree(new ExprTree());
      this.exprTree.setCellRenderer(new ExprRenderer(this.textFont));
      this.exprTree.setShowsRootHandles(false);
      this.exprTree.getSelectionModel().setSelectionMode(1);
      this.exprTree.getSelectionModel().addTreeSelectionListener(this.selExprNode);
      this.exprTree.addMouseListener(new MouseAdapter() {
         public void mouseClicked(MouseEvent e) {
            if (e.getButton() == 1 && e.getClickCount() >= 2) {
               MainFrame.this.enterAction.actionPerformed((ActionEvent)null);
            }

         }
      });
      JScrollPane exprScrl = new JScrollPane(this.exprTree);
      JSplitPane left = new JSplitPane(0, this.progPanel, exprScrl);
      this.stateTable = new JTable(new StateList());
      this.stateTable.getSelectionModel().setSelectionMode(0);
      this.stateTable.getSelectionModel().addListSelectionListener(this.selProgState);
      this.stateTable.setAutoResizeMode(0);
      this.stateTable.setFont(this.textFont);
      JScrollPane tableScrl = new JScrollPane(this.stateTable);
      this.callStack = new JList(new CallStack((StateList)this.stateTable.getModel(), this.prefDialog.getStepNum()));
      this.inpPanes = new JTabbedPane();
      this.outPanes = new JTabbedPane();
      JPanel states = new JPanel(new BorderLayout());
      if ("on".equals(System.getProperty("hu.ppke.itk.plang.subprograms"))) {
         states.add(this.callStack, "North");
      }

      states.add(tableScrl);
      JSplitPane console = new JSplitPane(1, this.inpPanes, this.outPanes);
      JSplitPane right = new JSplitPane(0, states, console);
      JSplitPane all = new JSplitPane(1, left, right);
      this.getContentPane().add(all);
      this.pack();
      left.setDividerLocation(0.7);
      console.setDividerLocation((double)0.5F);
      right.setDividerLocation(0.7);
      this.editState();
   }

   private class PlangFilter extends FileFilter {
      private PlangFilter() {
      }

      public boolean accept(File f) {
         if (f.isDirectory()) {
            return true;
         } else {
            String n = f.getName();
            return n.substring(n.lastIndexOf(46) + 1).toLowerCase().equals("plang");
         }
      }

      public String getDescription() {
         return "Plang programok (*.plang)";
      }

      // $FF: synthetic method
      PlangFilter(PlangFilter var2) {
         this();
      }
   }
}
