package hu.ppke.itk.plang.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.tree.TreeCellRenderer;

public class ExprRenderer extends JLabel implements TreeCellRenderer {
   final Color borderColor = UIManager.getColor("Tree.selectionBorderColor");
   final Color textBackg = UIManager.getColor("Tree.textBackground");
   final Color selectBackg = UIManager.getColor("Tree.selectionBackground");

   public ExprRenderer(Font font) {
      this.setFont(font);
      this.setOpaque(true);
   }

   public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
      this.setBorder(BorderFactory.createCompoundBorder(hasFocus ? BorderFactory.createLineBorder(this.borderColor) : BorderFactory.createEmptyBorder(1, 1, 1, 1), BorderFactory.createEmptyBorder(1, 1, 1, 1)));
      this.setBackground(selected ? this.selectBackg : this.textBackg);
      this.setText(value.toString() + (((ExprNode)value).getSubStates() != null ? " [ALPROGRAM]" : ""));
      return this;
   }
}
