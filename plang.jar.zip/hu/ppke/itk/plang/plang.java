package hu.ppke.itk.plang;

import hu.ppke.itk.plang.gui.MainFrame;
import javax.swing.SwingUtilities;

public class plang implements Runnable {
   public void run() {
      (new MainFrame()).setVisible(true);
   }

   public static void main(String[] args) {
      SwingUtilities.invokeLater(new plang());
   }
}
